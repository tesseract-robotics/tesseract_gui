qdarkstyle.light.palette module
===============================

.. automodule:: qdarkstyle.light.palette
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
