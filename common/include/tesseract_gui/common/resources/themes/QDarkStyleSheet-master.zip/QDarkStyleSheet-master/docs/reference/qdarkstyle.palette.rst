qdarkstyle.palette module
=========================

.. automodule:: qdarkstyle.palette
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
