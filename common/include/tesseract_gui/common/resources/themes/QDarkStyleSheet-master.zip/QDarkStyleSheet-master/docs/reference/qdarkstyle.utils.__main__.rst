qdarkstyle.utils.\_\_main\_\_ module
====================================

.. automodule:: qdarkstyle.utils.__main__
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
